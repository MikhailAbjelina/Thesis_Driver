package com.example.thesis_wfdriver;

public class UserLoginEvent {
    public final String busNumber;

    public UserLoginEvent(String busNumber) {
        this.busNumber = busNumber;
    }
}

