package com.example.thesis_wfdriver;

public class SharedData {
    private static final SharedData instance = new SharedData();
    private String busNumber;

    // Private constructor to prevent instantiation
    private SharedData() {}

    // Method to get the single instance of the class
    public static SharedData getInstance() {
        return instance;
    }

    // Getter and setter for busNumber
    public String getBusNumber() {
        return busNumber;
    }

    public void setBusNumber(String busNumber) {
        this.busNumber = busNumber;
    }
}
