package com.example.thesis_wfdriver;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.android.volley.RequestQueue;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.android.volley.toolbox.StringRequest;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import java.util.HashMap;
import com.android.volley.VolleyError;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import com.example.thesis_wfdriver.databinding.ActivityRouteSelectionBinding;
import org.osmdroid.util.GeoPoint;

import java.util.ArrayList;
import java.util.List;

public class RouteSelectionActivity extends AppCompatActivity {

    private ActivityRouteSelectionBinding binding;
    private String bus_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRouteSelectionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = getIntent();
        if (intent != null) {
            bus_number = intent.getStringExtra("bus_number");
        }

        binding.route1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectRoute(1);
            }
        });

        binding.route2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectRoute(2);
            }
        });

        binding.route3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectRoute(3);
            }
        });


        // Add a button to navigate to MainActivity
        binding.navigateToMainActivityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navigateToMainActivity();
            }
        });
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(RouteSelectionActivity.this, MainActivity.class);
        intent.putExtra("bus_number", bus_number); // Pass the bus number if needed
        startActivity(intent);
    }

    private void selectRoute(int routeNumber) {
        List<GeoPoint> waypoints = getRouteWaypoints(routeNumber);
        double latitude = 14.509501685679016;
        double longitude = 120.99079511166886;
        sendRouteToServer(routeNumber, waypoints);

        Intent intent = new Intent(RouteSelectionActivity.this, MainActivity.class);
        intent.putExtra("bus_number", bus_number);
        intent.putExtra("route", routeNumber);
        intent.putExtra("latitude", latitude);
        intent.putExtra("longitude", longitude);
        startActivity(intent);
    }

    private List<GeoPoint> getRouteWaypoints(int routeNumber) {
        List<GeoPoint> waypoints = new ArrayList<>();
        switch (routeNumber) {
            case 1:
                waypoints.add(new GeoPoint(14.120285484470212, 120.9090610539933));
                waypoints.add(new GeoPoint(14.118648, 120.960975));
                waypoints.add(new GeoPoint(14.509501685679016, 120.99079511166886));
                break;
            case 2:
                waypoints.add(new GeoPoint(14.287866614713472, 121.00013006251946));
                waypoints.add(new GeoPoint(14.417718804975594, 120.97462599632549));
                waypoints.add(new GeoPoint(14.509501685679016, 120.99079511166886));
                break;
            case 3:
                waypoints.add(new GeoPoint(14.487014389993611, 120.90254173128984));
                waypoints.add(new GeoPoint(14.432854584276043, 120.88625216276692));
                waypoints.add(new GeoPoint(14.509501685679016, 120.99079511166886));
                break;
        }
        return waypoints;
    }

    private void sendRouteToServer(final int routeNumber, final List<GeoPoint> waypoints) {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://busgoapplication.com/dvrupdate_route.php";

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("RouteSelectionActivity", "Server Response: " + response);
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            if (success) {
                                Toast.makeText(RouteSelectionActivity.this, "Route selected successfully!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(RouteSelectionActivity.this, MainActivity.class);
                                intent.putExtra("bus_number", bus_number);
                                intent.putExtra("route", routeNumber);
                                startActivity(intent);
                            } else {
                                Toast.makeText(RouteSelectionActivity.this, "Error selecting route", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(RouteSelectionActivity.this, "Error parsing response", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String errorMessage = "";
                        if (error.networkResponse != null) {
                            errorMessage = "Error code: " + error.networkResponse.statusCode + ", " + new String(error.networkResponse.data);
                        } else {
                            errorMessage = error.toString();
                        }
                        Toast.makeText(RouteSelectionActivity.this, "Error connecting to server: " + errorMessage, Toast.LENGTH_LONG).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("bus_number", bus_number);
                params.put("route_number", String.valueOf(routeNumber));
                params.put("waypoints", waypointsToString(waypoints));
                return params;
            }
        };

        queue.add(postRequest);
    }

    private String waypointsToString(List<GeoPoint> waypoints) {
        StringBuilder sb = new StringBuilder();
        for (GeoPoint point : waypoints) {
            sb.append(point.getLatitude()).append(",").append(point.getLongitude()).append(";");
        }
        return sb.toString();
    }
}
