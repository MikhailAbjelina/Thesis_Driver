package com.example.thesis_wfdriver;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Announcements extends AppCompatActivity {

    private static final String URL = "https://busgoapplication.com/get_announcements.php";
    private TextView textView;
    private static final String TAG = "AnnouncementsActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcements);
        textView = findViewById(R.id.textView);
        fetchAnnouncements();
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to MainActivity when the back button is pressed
                Intent intent = new Intent(Announcements.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void fetchAnnouncements() {
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(TAG, "Response received: " + response);
                        displayAnnouncements(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (error.networkResponse != null) {
                            Log.e(TAG, "Error response code: " + error.networkResponse.statusCode);
                            textView.setText("Error fetching data: " + error.networkResponse.statusCode);
                        } else {
                            Log.e(TAG, "Error fetching data", error);
                            textView.setText("Error fetching data: " + error.getMessage());
                        }
                    }
                });

        queue.add(stringRequest);
    }

    private void displayAnnouncements(String jsonResponse) {
        try {
            JSONArray jsonArray = new JSONArray(jsonResponse);
            StringBuilder displayResult = new StringBuilder();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                displayResult.append("Title: ").append(jsonObject.getString("title")).append("\n")
                        .append("Message: ").append(jsonObject.getString("message")).append("\n")
                        .append("Created At: ").append(jsonObject.getString("created_at")).append("\n\n");
            }
            textView.setText(displayResult.toString());
            JSONObject latestAnnouncement = jsonArray.getJSONObject(jsonArray.length() - 1);
            String title = latestAnnouncement.getString("title");
            String createdAt = latestAnnouncement.getString("created_at");

            // Show toast with the latest title and date
            String toastMessage = "Latest Report: " + title + "\nDate: " + createdAt;
            Toast toast = Toast.makeText(Announcements.this, toastMessage, Toast.LENGTH_LONG);
            toast.setGravity(Gravity.FILL_HORIZONTAL, 0, 0);
            toast.show();
        } catch (JSONException e) {
            Log.e(TAG, "Error parsing data", e);
            textView.setText("Error parsing data: " + e.getMessage());
        }
    }
}