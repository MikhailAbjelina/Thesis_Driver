package com.example.thesis_wfdriver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.location.Location;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private EditText loginBus;
    private EditText loginPassword;
    private Button loginButton;
    private FusedLocationProviderClient fusedLocationClient;
    static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private String loggedInBus;

    String busNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.activity_login);

        // Initialize views
        loginBus = findViewById(R.id.login_bus);
        loginPassword = findViewById(R.id.login_password);
        loginButton = findViewById(R.id.login_button);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        loggedInBus = loginBus.getText().toString();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                authenticateUser();
            }
        });
    }

    private void authenticateUser() {
        String busNumber = loginBus.getText().toString().trim();
        String password = loginPassword.getText().toString().trim();

        if (busNumber.isEmpty() || password.isEmpty()) {
            Toast.makeText(LoginActivity.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
            return;
        }

        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://busgoapplication.com/dvrlogin.php"; // Replace with your API endpoint URL

        StringRequest postRequest = new StringRequest(com.android.volley.Request.Method.POST, url,
                response -> {
                    try {
                        Log.d("LoginActivity", "Response: " + response);
                        JSONObject jsonResponse = new JSONObject(response);
                        boolean success = jsonResponse.getBoolean("success");

                        if (success) {
                            EventBus.getDefault().postSticky(new UserLoginEvent(busNumber));
                            SharedData.getInstance().setBusNumber(busNumber);
                            Toast.makeText(getApplicationContext(), "Login Successfully!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(this, MainActivity.class);
                            intent.putExtra("busnum", busNumber);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(LoginActivity.this, "Error parsing response", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    String errorMessage = "";
                    if (error.networkResponse != null) {
                        errorMessage = "Error code: " + error.networkResponse.statusCode + ", " + new String(error.networkResponse.data);
                    } else {
                        errorMessage = error.toString();
                    }
                    Log.e("LoginActivity", "Error: " + errorMessage);
                    Toast.makeText(LoginActivity.this, "Error connecting to server: " + errorMessage, Toast.LENGTH_LONG).show();
                }
        ) {
            @Override
            protected java.util.Map<String, String> getParams() {
                java.util.Map<String, String> params = new java.util.HashMap<>();
                params.put("bus_number", busNumber);
                params.put("password", password);
                return params;
            }
        };

        queue.add(postRequest);
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            getLocationAndSendToServer();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLocationAndSendToServer();
            } else {
                Toast.makeText(this, "Location permission is required to send location data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void getLocationAndSendToServer() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    sendLocationToServer(location);
                }
            }
        });
    }

    private void sendLocationToServer(Location location) {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://busgoapplication.com/dvrupdate_location.php"; // Replace with your API endpoint URL

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("LoginActivity", "Location update response: " + response);
                        Toast.makeText(LoginActivity.this, "Location sent successfully", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String errorMessage = "";
                        if (error.networkResponse != null) {
                            errorMessage = "Error code: " + error.networkResponse.statusCode + ", " + new String(error.networkResponse.data);
                        } else {
                            errorMessage = error.toString();
                            Intent intent = new Intent();
                            intent.putExtra("busNumber", busNumber);
                        }
                        Log.e("LoginActivity", "Location update error: " + errorMessage);
                        Toast.makeText(LoginActivity.this, "Error sending location: " + errorMessage, Toast.LENGTH_LONG).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("bus_number", loggedInBus); // Use the saved bus number
                params.put("latitude", String.valueOf(location.getLatitude()));
                params.put("longitude", String.valueOf(location.getLongitude()));
                return params;
            }
        };
        queue.add(postRequest);
    }
}


