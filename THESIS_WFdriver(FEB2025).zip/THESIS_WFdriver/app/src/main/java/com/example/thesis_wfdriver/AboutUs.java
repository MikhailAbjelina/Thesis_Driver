package com.example.thesis_wfdriver;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

public class AboutUs extends AppCompatActivity {
    private String bus_number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        bus_number = getIntent().getStringExtra("bus_number");
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("bus_number", bus_number);
                startActivity(intent);
                finish(); // Close the AboutUsActivity and go back to the previous activity
            }
        });
    }
}