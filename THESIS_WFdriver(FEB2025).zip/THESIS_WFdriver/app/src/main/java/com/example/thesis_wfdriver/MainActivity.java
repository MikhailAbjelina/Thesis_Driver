package com.example.thesis_wfdriver;

import static com.example.thesis_wfdriver.LoginActivity.LOCATION_PERMISSION_REQUEST_CODE;
import android.Manifest;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import java.io.UnsupportedEncodingException;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.osmdroid.api.IGeoPoint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import org.osmdroid.config.Configuration;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;
import org.osmdroid.views.overlay.OverlayWithIW;
import org.osmdroid.views.overlay.Polyline;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;
import android.preference.PreferenceManager;
import android.widget.TextView;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.example.thesis_wfdriver.KalmanFilter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import org.osmdroid.bonuspack.routing.OSRMRoadManager;
import org.osmdroid.bonuspack.routing.Road;
import org.osmdroid.bonuspack.routing.RoadManager;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 1;
    private MapView mapView;
    private MyLocationNewOverlay myLocationOverlay;
    private double currentLatitude;
    private double currentLongitude;
    private Location previousLocation;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private RequestQueue requestQueue;
    private KalmanFilter kalmanFilter;
    private DrawerLayout drawerLayout;
    private Spinner locationSpinner;
    private TextView speedTextView;
    String route;
    FloatingActionButton fab;
    private long startTime;
    private TextView timerTextView;
    private String startDate;
    private String elapsedTimeString = "";
    private Handler timerHandler = new Handler();
    private Button timerButton;
    private boolean isTimerRunning = false;
    private List<OverlayWithIW> routeOverlays = new ArrayList<>();
    private Runnable locationUpdateRunnable;
    private String BusNumber;
    String bus_Number;
    private double initialLatitude;
    private double initialLongitude;
    private double finalLatitude = 14.509501685679016;
    private double finalLongitude = 120.99079511166886;
    private double departLat;
    private double departLong;
    private double arriveLat;
    private double arriveLong;
    private String departTime;
    private String logTime;
    private Handler handler = new Handler();
    private double kfTime;
    private List<double[]> gTruth;
    private List<double[]> estimates;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        // Set up osmdroid configuration, usually in the onCreate of your main activity
        Configuration.getInstance().load(this, PreferenceManager.getDefaultSharedPreferences(this));
        Configuration.getInstance().setUserAgentValue("MyOwnUserAgent/1.0");
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        bus_Number = intent.getStringExtra("busnum");
        BusNumber = bus_Number;
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        logTime = timeFormat.format(new Date());
        locationSpinner = findViewById(R.id.locationSpinner);
        mapView = findViewById(R.id.mapView);
        kalmanFilter = new KalmanFilter(0, 0);
        requestQueue = Volley.newRequestQueue(this);
        speedTextView = findViewById(R.id.speedTextView);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        estimatedLatitudeTextView = findViewById(R.id.estimatedLatitudeTextView);
        estimatedLongitudeTextView = findViewById(R.id.estimatedLongitudeTextView);
        distanceTextView = findViewById(R.id.distanceTextView);
        remainingTimeTextView = findViewById(R.id.remainingTimeTextView);
        startDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());


        // Check for location permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
        } else {
            // Permissions are granted, initialize map with GPS
            initializeMap();
            startLocationUpdates();
            retrieveBusNumberAndStartLocationUpdates();
            requestLocationUpdates();
        }
            double latitude = intent.getDoubleExtra("latitude", -1);
            double longitude = intent.getDoubleExtra("longitude", -1);
            if (latitude != -1 && longitude != -1) {
                moveToLocation(latitude, longitude);
            }
        //Setup Navigation Menu
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                drawerLayout.closeDrawer(GravityCompat.START);
                if (id == R.id.nav_profile) {
                    Intent intent = new Intent(MainActivity.this, AccountView.class);
                    startActivity(intent);
                } else if (id == R.id.nav_announcement) {
                    Intent intent = new Intent(MainActivity.this, Announcements.class);
                    startActivity(intent);
                } else if (id == R.id.nav_settings) {
                    Intent intent = new Intent(MainActivity.this, Settings.class);
                    startActivity(intent);
                } else if (id == R.id.nav_history) {
                    Intent intent = new Intent(MainActivity.this, History.class);
                    startActivity(intent);
                } else if (id == R.id.nav_about) {
                    Intent intent = new Intent(MainActivity.this, AboutUs.class);
                    startActivity(intent);
                } else if (id == R.id.nav_logout) {
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
                new Handler().postDelayed(() -> {
                    drawerLayout.closeDrawer(GravityCompat.START);
                }, 250); // delay in milliseconds
                return true;
            }
        });
        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showBottomDialog();
            }
        });

        locationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Handle item selection
                String selectedItem = parent.getItemAtPosition(position).toString();
                if (position == 0) {
                    route = selectedItem;
                    departLat = 14.120285484470212;
                    departLong = 120.9090610539933;
                    arriveLat = 14.509501685679016;
                    arriveLong = 120.99079511166886;
                    kfTime = kalmanFilter.timeRemainingMinutes(14.509501685679016, 120.99079511166886);
                } else if (position == 1) {
                    route = selectedItem;
                    departLat = 14.287866614713472;
                    departLong = 121.00013006251946;
                    arriveLat = 14.509501685679016;
                    arriveLong = 120.99079511166886;
                    kfTime = kalmanFilter.timeRemainingMinutes(14.509501685679016, 120.99079511166886);
                } else if (position == 2) {
                    route = selectedItem;
                    departLat = 14.487014389993611;
                    departLong = 120.90254173128984;
                    arriveLat = 14.509501685679016;
                    arriveLong = 120.99079511166886;
                    kfTime = kalmanFilter.timeRemainingMinutes(14.509501685679016, 120.99079511166886);
                } else if (position == 3){
                    route = selectedItem;
                    departLat = 14.510180438746158;
                    departLong = 120.99092025344035;
                    arriveLat = 14.120111154056406;
                    arriveLong = 120.90921410865793;
                    kfTime = kalmanFilter.timeRemainingMinutes(14.120111154056406, 120.90921410865793);
                } else if (position == 4){
                    route = selectedItem;
                    departLat = 14.510180438746158;
                    departLong = 120.99092025344035;
                    arriveLat = 14.287221247673578;
                    arriveLong = 121.00038124642944;
                    kfTime = kalmanFilter.timeRemainingMinutes(14.287221247673578, 121.00038124642944);
                } else if (position == 5){
                    route = selectedItem;
                    departLat = 14.510180438746158;
                    departLong = 120.99092025344035;
                    arriveLat = 14.486637109963517;
                    arriveLong = 120.90252274304017;
                    kfTime = kalmanFilter.timeRemainingMinutes(14.486637109963517, 120.90252274304017);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                route = "";
            }
        });
        timerButton = findViewById(R.id.timerButton);
        timerTextView = findViewById(R.id.timerTextView);
        timerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isTimerRunning) {
                    String date;
                    String elapsedTime;
                    // Stop the timer
                    timerHandler.removeCallbacks(timerRunnable);
                    timerButton.setText("Start Timer");
                    date = startDate;
                    elapsedTime = getElapsedTimeString();
                    if (route == "") {
                        Toast.makeText(MainActivity.this, "Route must be Selected", Toast.LENGTH_SHORT).show();
                    } else {
                        sendTime(bus_Number, date, kalmanFilter.timeRemainingMinutes(finalLatitude, finalLongitude), logTime, route, departLat, departLong, departTime, arriveLat, arriveLong);
                        startRepeatingTask();
                    }
                    isTimerRunning = false;
                } else {
                    // Start the timer
                    SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
                    departTime = timeFormat.format(new Date());
                    startTime = System.currentTimeMillis();
                    timerHandler.postDelayed(timerRunnable, 0);
                    timerButton.setText("End Timer");
                    isTimerRunning = true;
                }
            }
        });
        Log.d("MainActivity", "BusNumber: " + bus_Number);
    }

    private void requestLocationUpdates() {
        // Check location permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            // Request location updates
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if (location != null) {
                                // Update KalmanFilter with initial location
                                kalmanFilter = new KalmanFilter(location.getLatitude(), location.getLongitude());
                                // Update TextViews with initial location
                                updateTextViewsWithLocationInfo(location.getLatitude(), location.getLongitude());
                            }
                        }
                    });
        } else {
            // Request location permissions
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
    }

    // Method to dynamically update the displayed speed when receiving a new location update
    private void updateSpeedUI(Location previousLocation, Location currentLocation) {
        if (previousLocation != null && currentLocation != null) {
            float speedInMetersPerSecond = currentLocation.getSpeed();
            float speedInKilometersPerHour = speedInMetersPerSecond * 3.6f; // Convert to km/h
            speedTextView.setText("Speed: " + String.format("%.2f", speedInKilometersPerHour) + " km/h");

            // Update KalmanFilter average speed
            kalmanFilter.setAverageSpeed(speedInKilometersPerHour);
        }
    }

    // Method to calculate speed based on distance between two locations and time elapsed
    private float calculateSpeed(Location previousLocation, Location currentLocation) {
        float distanceInMeters = previousLocation.distanceTo(currentLocation);
        long timeInMillis = currentLocation.getTime() - previousLocation.getTime();
        float speedInMetersPerSecond = distanceInMeters / timeInMillis * 1000; // Convert to meters per second
        return speedInMetersPerSecond * 3.6f; // Convert to kilometers per hour
    }

    // Method to handle new location updates


    private TextView estimatedLatitudeTextView;
    private TextView estimatedLongitudeTextView;
    private TextView distanceTextView;
    private TextView remainingTimeTextView;

    // Call this method whenever you receive a new location update in your app
    private void onNewLocationReceived(Location location) {
        updateSpeedUI(previousLocation, location);
        previousLocation = location;

        // Update KalmanFilter with the new location
        double[] measurement = {location.getLatitude(), location.getLongitude()};
        kalmanFilter.predict();
        kalmanFilter.update(measurement);

        // Update the text views with KalmanFilter information
        updateTextViewsWithLocationInfo(kalmanFilter.getCurrentState()[0], kalmanFilter.getCurrentState()[1]);
    }

    private void moveToLocation(double latitude, double longitude) {
        GeoPoint geoPoint = new GeoPoint(latitude, longitude);
        mapView.getController().setCenter(geoPoint);
        mapView.getController().setZoom(15.0);  // Adjust zoom level as needed
    }

    private void retrieveBusNumberAndStartLocationUpdates() {
        String url = "https://busgoapplication.com/dvrsignup.php";

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        BusNumber = response.trim();
                        if (BusNumber == null || BusNumber.isEmpty()) {
                            Toast.makeText(MainActivity.this, "No bus number retrieved", Toast.LENGTH_SHORT).show();
                        } else {
                            startLocationUpdates();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "Error retrieving bus number", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(stringRequest);
    }

    private void initializeMap() {
        mapView.setTileSource(org.osmdroid.tileprovider.tilesource.TileSourceFactory.MAPNIK);

        // Enable zoom controls
        mapView.setBuiltInZoomControls(true);
        mapView.setMultiTouchControls(true);

        // Create MyLocation overlay
        myLocationOverlay = new MyLocationNewOverlay(mapView);
        mapView.getOverlays().add(myLocationOverlay);

        // Enable My Location overlay (blue dot representing user's location)
        GpsMyLocationProvider locationProvider = new GpsMyLocationProvider(this);
        myLocationOverlay.enableMyLocation(locationProvider);

        // Enable follow location for continuous updates
        myLocationOverlay.enableFollowLocation();

        // Center the map on the user's location
        Location lastKnownLocation = locationProvider.getLastKnownLocation();
        if (lastKnownLocation != null) {
            mapView.getController().setCenter(new GeoPoint(lastKnownLocation));
        }

        // Set an appropriate zoom level
        mapView.getController().setZoom(12.0);
    }


    private void updateTextViewsWithLocationInfo(double latitude, double longitude) {
        // Update KalmanFilter object with initial location
        double[] currentState = kalmanFilter.getCurrentState();
        double currentLatitude = currentState[0];
        double currentLongitude = currentState[1];
        kalmanFilter = new KalmanFilter(latitude, longitude);


        kalmanFilter.setFinalDestination(finalLatitude, finalLongitude);

        // Retrieve average speed from KalmanFilter instance
        double averageSpeedKmh = kalmanFilter.getAverageSpeed(); // Use the instance method to get the average speed


                // Calculate distance to final destination
        double distanceToFinal = kalmanFilter.distanceToFinal();

        // Calculate remaining time
        double remainingTimeInMinutes = kalmanFilter.timeRemainingMinutes(finalLatitude, finalLongitude);


        TextView estimatedLatitudeTextView = findViewById(R.id.estimatedLatitudeTextView);
        TextView estimatedLongitudeTextView = findViewById(R.id.estimatedLongitudeTextView);
        TextView distanceTextView = findViewById(R.id.distanceTextView);
        TextView remainingTimeTextView = findViewById(R.id.remainingTimeTextView);

        // Update TextViews with the calculated values
        estimatedLatitudeTextView.setText(String.format("Estimated Latitude: %.4f", currentLatitude));
        estimatedLongitudeTextView.setText(String.format("Estimated Longitude: %.4f", currentLongitude));
        distanceTextView.setText(String.format("Distance from Destination: %.2f km", distanceToFinal));
        remainingTimeTextView.setText(String.format("Remaining Time: %.2f minutes", remainingTimeInMinutes));

        // Send remaining time to server
        sendRemainingTimeToServer(BusNumber, remainingTimeInMinutes);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (fusedLocationClient != null && locationCallback != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
        super.onDestroy();
        stopRepeatingTask();
    }

    private void updateLocationOnServer(Location location) {
        String url = "https://busgoapplication.com/dvrupdate_location.php";

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        //Toast.makeText(MainActivity.this, "Location updated successfully", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle the error
                        Toast.makeText(MainActivity.this, "Error updating location", Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("bus_number", BusNumber);
                params.put("latitude", String.valueOf(location.getLatitude()));
                params.put("longitude", String.valueOf(location.getLongitude()));
                return params;
            }
        };

        // Add the request to the RequestQueue
        Volley.newRequestQueue(this).add(postRequest);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates();
            } else {
                Toast.makeText(this, "Location permission denied, unable to send location data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            long elapsedMillis = System.currentTimeMillis() - startTime;
            int seconds = (int) (elapsedMillis / 1000);
            int minutes = seconds / 60;
            int hours = minutes / 60;
            seconds = seconds % 60;
            minutes = minutes % 60;
            timerTextView.setText(String.format("Date: %s\nElapsed Time: %02d:%02d:%02d", startDate, hours, minutes, seconds));
            elapsedTimeString = String.format("%02d:%02d:%02d", hours, minutes, seconds);
            timerHandler.postDelayed(this, 1000);
        }
    };

    private void startLocationUpdates() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(3000); // 10 seconds
        locationRequest.setFastestInterval(2000); // 5 seconds
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        Handler handler = new Handler();

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location!= null) {
                        updateLocationOnServer(location);
                        onNewLocationReceived(location);
                    }
                }
            }
        };

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
        locationUpdateRunnable = new Runnable() {
            @Override
            public void run() {
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION)!= PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
                    return;
                }
                // Trigger location update
                fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
                myLocationOverlay.enableFollowLocation();
                GpsMyLocationProvider locationProvider = new GpsMyLocationProvider(MainActivity.this);
                Location lastKnownLocation = locationProvider.getLastKnownLocation();
                if (lastKnownLocation!= null) {
                    mapView.getController().setCenter(new GeoPoint(lastKnownLocation));
                    Log.e("UserLocationRunning", "UserLocation is constantly running");
                }
            }
        };
    }

    private void sendRemainingTimeToServer(String busNumber, double remainingTimeInMinutes) {
        String url = "https://busgoapplication.com/dvrTimeEst.php";

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Log.i("ServerResponse", "Response: " + response);
                        //Toast.makeText(MainActivity.this, "Time arrival updated successfully!", Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle the error
                        String errorMessage = "Error updating time arrival!";
                        if (error.networkResponse != null) {
                            errorMessage += " Status code: " + error.networkResponse.statusCode;
                            if (error.networkResponse.data != null) {
                                try {
                                    String responseBody = new String(error.networkResponse.data, "utf-8");
                                    errorMessage += " Response body: " + responseBody;
                                } catch (UnsupportedEncodingException e) {
                                    Log.e("EncodingError", "Unsupported encoding", e);
                                }
                            }
                        }
                        Log.e("VolleyError", errorMessage);
                        Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("bus_number", busNumber);
                params.put("remaining_time", String.valueOf(remainingTimeInMinutes));
                return params;
            }
        };

        // Add the request to the RequestQueue
        requestQueue.add(postRequest);
    }
    private void updateRouteOnServer(final String bus_number, final String route) {
        try {
            String requestUrl = "https://busgoapplication.com/dvrupdate_route.php"; // Replace with your PHP script URL
            StringRequest stringRequest = new StringRequest(Request.Method.POST, requestUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Handle response
                            Toast.makeText(MainActivity.this, "Route Updated Successfully!", Toast.LENGTH_SHORT).show();
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Handle error
                    Toast.makeText(MainActivity.this, "Failed to Update Route!", Toast.LENGTH_SHORT).show();
                    Log.e("UpdateRouteError", "Failed to update route: " + error.toString());
                }
            }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("bus_number", bus_number);
                    params.put("route", route);
                    return params;
                }
            };

            // Add the request to the RequestQueue.
            Volley.newRequestQueue(this).add(stringRequest);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Error sending data to server", Toast.LENGTH_SHORT).show();
        }
    }

    public String getElapsedTimeString() {
        return elapsedTimeString;
    }

    private void sendTime(String BusNumber, String date, double elapsedTime, String logTime, String route, double departLat, double departLong, String departTime, double arriveLat, double arriveLong) {
        try {
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            Date departureDate = timeFormat.parse(departTime);
            if (departureDate == null) {
                throw new IllegalArgumentException("Invalid departure time format");
            }

            // Convert kfTime from minutes to milliseconds
            long kfTimeMillis = (long) (kfTime * 60 * 1000);

            // Add kfTimeMillis to departureDate
            Date updatedTime = new Date(departureDate.getTime() + kfTimeMillis);

            // Format the updated time back into a string
            String arriveTime = timeFormat.format(updatedTime);
            String requestUrl = "https://busgoapplication.com/driverReports.php"; // Replace with your PHP script URL
            RequestQueue queue = Volley.newRequestQueue(this);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, requestUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Handle response
                            Toast.makeText(MainActivity.this, "Feedback Sent!", Toast.LENGTH_SHORT).show();
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Handle error
                    Toast.makeText(MainActivity.this, "Feedback Not Sent!", Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("bus_number", BusNumber);
                    params.put("date", date);
                    params.put("duration", String.valueOf(elapsedTime));
                    params.put("route", route);
                    params.put("departLat", String.valueOf(departLat));
                    params.put("departLong", String.valueOf(departLong));
                    params.put("departTime", departTime);
                    params.put("arriveLat", String.valueOf(arriveLat));
                    params.put("arriveLong", String.valueOf(arriveLong));
                    params.put("arriveTime", arriveTime);
                    params.put("logTime", logTime);
                    return params;
                }
            };

            // Add the request to the RequestQueue.
            queue.add(stringRequest);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Error sending data to server", Toast.LENGTH_SHORT).show();
        }
    }
    private final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            String currentTime = timeFormat.format(new Date());
            String formattedLatitude = String.format("%.4f", currentLatitude);
            double limitedLatitude = Double.parseDouble(formattedLatitude);
            String formattedLongitude = String.format("%.4f", currentLongitude);
            double limitedLongitude = Double.parseDouble(formattedLongitude);
            List<double[]> groundTruth = kalmanFilter.getGroundTruth();  // Assuming this is how you get it
            List<double[]> estimates = kalmanFilter.getEstimates();  // Similarly, retrieve the estimates
            if (previousLocation != null) {
                sendDataToServer(startDate, bus_Number, currentTime, previousLocation.getLatitude(), previousLocation.getLongitude(),
                        limitedLatitude, limitedLongitude, kalmanFilter.nis, 10.1, 10.1,
                        route);
            } else {
                //log check
                Log.e("MainActivity", "previousLocation is null, skipping sendDataToServer()");
            }
 // Your function to execute
            handler.postDelayed(this, 3 * 60 * 1000); // 3 minutes in milliseconds
        }
    };

    private void startRepeatingTask() {
        runnable.run();
    }

    private void stopRepeatingTask() {
        handler.removeCallbacks(runnable);
    }
    private void sendDataToServer(String date, String BusNumber, String time,
                                  double currentLat, double currentLng,
                                  double estimatedLat, double estimatedLng,
                                  double mae, double rmse, double mape, String route) {
        String url = "https://busgoapplication.com/algoReports.php"; // Replace with your endpoint URL

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Log.i("SendData", "Data sent successfully: " + response);
                        Toast.makeText(MainActivity.this, "Data sent successfully", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle the error
                        Log.e("SendData", "Error sending data: " + error.toString());
                        Toast.makeText(MainActivity.this, "Failed to send data", Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("date", date);
                params.put("bus_number", BusNumber);
                params.put("time", time);
                params.put("current_lat", String.valueOf(currentLat));
                params.put("current_lng", String.valueOf(currentLng));
                params.put("estimated_lat", String.valueOf(estimatedLat));
                params.put("estimated_lng", String.valueOf(estimatedLng));
                params.put("mae", String.valueOf(mae));
                params.put("rmse", String.valueOf(rmse));
                params.put("mape", String.valueOf(mape));
                params.put("route", route);
                return params;
            }
        };

        // Add the request to the RequestQueue
        requestQueue.add(postRequest);
    }
    private void showBottomDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.bottomsheetlayout);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        LinearLayout mendezLayout = dialog.findViewById(R.id.mendez);
        LinearLayout genMarAlvarezLayout = dialog.findViewById(R.id.genmaralvarez);
        LinearLayout caviteCityLayout = dialog.findViewById(R.id.cavitecity);
        LinearLayout toMendez = dialog.findViewById(R.id.pitx2Mendez);
        LinearLayout toGenMar = dialog.findViewById(R.id.pitx2GenMar);
        LinearLayout toCavite = dialog.findViewById(R.id.pitx2Cavite);
        ImageView cancelButton = dialog.findViewById(R.id.cancelButton);

        mendezLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCoordinatesForMendez();
                dialog.dismiss();
            }
        });

        genMarAlvarezLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCoordinatesForGMA();
                dialog.dismiss();

            }
        });

        caviteCityLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCoordinatesForPadua();
                dialog.dismiss();

            }
        });

        toMendez.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCoordinatesToMendez();
                dialog.dismiss();

            }
        });

        toGenMar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCoordinatesToGenMar();
                dialog.dismiss();
            }
        });

        toCavite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCoordinatesToCavite();
                dialog.dismiss();

            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
//----------------------------------------------------------------------------------------------------------------------
    private void getCoordinatesForMendez() {
        RoadManager roadManager = new OSRMRoadManager(this, "MyOwnUserAgent/1.0");
        GeoPoint startLocation = new GeoPoint(14.120316698482938, 120.90910396933543);
        mapView.getController().setCenter(startLocation);
        mapView.getController().setZoom(18.0); // Set an appropriate zoom level
        // Update currentLatitude and currentLongitude
        currentLatitude = startLocation.getLatitude();
        currentLongitude = startLocation.getLongitude();
        ArrayList<GeoPoint> waypoints = new ArrayList<GeoPoint>();
        GeoPoint start = new GeoPoint(14.120285484470212, 120.9090610539933);
        waypoints.add(start);
        GeoPoint midPoint = new GeoPoint(14.101901, 120.921509);
        waypoints.add(midPoint);
        GeoPoint midPoint1 = new GeoPoint(14.115821456856606, 120.96172893048771);
        waypoints.add(midPoint1);
        GeoPoint midPoint2 = new GeoPoint(14.287145901121493, 120.95939357047006);
        waypoints.add(midPoint2);
        GeoPoint midPoint3 = new GeoPoint(14.29086498610908, 120.95894245399518);
        waypoints.add(midPoint3);
        GeoPoint midPoint4 = new GeoPoint(14.322870844073693, 120.93810110822255);
        waypoints.add(midPoint4);
        GeoPoint midPoint5 = new GeoPoint(14.32722125685193, 120.93538134826866);
        waypoints.add(midPoint5);
        GeoPoint midPoint6 = new GeoPoint(14.327683, 120.936056);
        waypoints.add(midPoint6);
        GeoPoint midPoint7 = new GeoPoint(14.32947065440676, 120.93959651748473);
        waypoints.add(midPoint7);
        GeoPoint destination = new GeoPoint(14.509501685679016, 120.99079511166886);
        waypoints.add(destination);
        fetchTrafficData(waypoints, new TrafficDataCallback() {
            @Override
            public void onTrafficDataFetched(JSONObject trafficData) {
                updateMapWithTrafficData(waypoints, trafficData);
            }
        });
        initialLongitude = 14.120316698482938;
        initialLatitude = 120.90910396933543;
        finalLatitude = 14.509501685679016;
        finalLongitude = 120.99079511166886;
        kalmanFilter.setFinalDestination(finalLatitude, finalLongitude);
        updateRouteOnServer(BusNumber, "MENDEZ-PITX");
    }

    private void getCoordinatesForGMA() {
        RoadManager roadManager = new OSRMRoadManager(this, "MyOwnUserAgent/1.0");
        // Replace this with the actual coordinates for your predefined locations
        GeoPoint startLocation = new GeoPoint(14.287866614713472, 121.00013006251946);
        mapView.getController().setCenter(startLocation);
        mapView.getController().setZoom(18.0); // Set an appropriate zoom level
        // Update currentLatitude and currentLongitude
        currentLatitude = startLocation.getLatitude();
        currentLongitude = startLocation.getLongitude();
        ArrayList<GeoPoint> waypoints = new ArrayList<GeoPoint>();
        GeoPoint start = new GeoPoint(14.287866614713472, 121.00013006251946);
        waypoints.add(start);
        GeoPoint midPoint = new GeoPoint(14.417718804975594, 120.97462599632549);
        waypoints.add(midPoint);
        GeoPoint midPoint7 = new GeoPoint(14.434962, 120.973063);
        waypoints.add(midPoint7);
        GeoPoint destination = new GeoPoint(14.509501685679016, 120.99079511166886);
        waypoints.add(destination);
        fetchTrafficData(waypoints, new TrafficDataCallback() {
            @Override
            public void onTrafficDataFetched(JSONObject trafficData) {
                updateMapWithTrafficData(waypoints, trafficData);
            }
        });
        initialLongitude = 14.287866614713472;
        initialLatitude = 121.00013006251946;
        finalLatitude = 14.509501685679016;
        finalLongitude = 120.99079511166886;
        kalmanFilter.setFinalDestination(finalLatitude, finalLongitude);
        updateRouteOnServer(BusNumber, "GMA-PITX");
    }

    private void getCoordinatesForPadua() {
        RoadManager roadManager = new OSRMRoadManager(this, "MyOwnUserAgent/1.0");
        // Replace this with the actual coordinates for your predefined locations
        GeoPoint startLocation = new GeoPoint(14.487014389993611, 120.90254173128984);
        mapView.getController().setCenter(startLocation);
        mapView.getController().setZoom(18.0); // Set an appropriate zoom level
        // Update currentLatitude and currentLongitude
        currentLatitude = startLocation.getLatitude();
        currentLongitude = startLocation.getLongitude();
        ArrayList<GeoPoint> waypoints = new ArrayList<GeoPoint>();
        GeoPoint start = new GeoPoint(14.487014389993611, 120.90254173128984);
        waypoints.add(start);
        GeoPoint midPoint = new GeoPoint(14.432854584276043, 120.88625216276692);
        waypoints.add(midPoint);
        GeoPoint destination = new GeoPoint(14.509501685679016, 120.99079511166886);
        waypoints.add(destination);
        fetchTrafficData(waypoints, new TrafficDataCallback() {
            @Override
            public void onTrafficDataFetched(JSONObject trafficData) {
                updateMapWithTrafficData(waypoints, trafficData);
            }
        });
        initialLongitude = 14.487014389993611;
        initialLatitude = 120.90254173128984;
        finalLatitude = 14.509501685679016;
        finalLongitude = 120.99079511166886;
        kalmanFilter.setFinalDestination(finalLatitude, finalLongitude);
        updateRouteOnServer(BusNumber, "CAVITE CITY-PITX");
    }

    private void getCoordinatesToMendez() {
        RoadManager roadManager = new OSRMRoadManager(this, "MyOwnUserAgent/1.0");
        // Replace this with the actual coordinates for your predefined locations
        GeoPoint startLocation = new GeoPoint(14.510180438746158, 120.99092025344035);
        mapView.getController().setCenter(startLocation);
        mapView.getController().setZoom(18.0); // Set an appropriate zoom level
        // Update currentLatitude and currentLongitude
        currentLatitude = startLocation.getLatitude();
        currentLongitude = startLocation.getLongitude();
        ArrayList<GeoPoint> waypoints = new ArrayList<GeoPoint>();

        // Updated coordinates
        GeoPoint start = new GeoPoint(14.508206, 120.988391);
        waypoints.add(start);
        GeoPoint midPoint = new GeoPoint(14.506040, 120.987620);
        waypoints.add(midPoint);
        GeoPoint midPoint1 = new GeoPoint(14.504765, 120.990062);
        waypoints.add(midPoint1);
        GeoPoint midPoint2 = new GeoPoint(14.502448, 120.989799);
        waypoints.add(midPoint2);
        GeoPoint midPoint3 = new GeoPoint(14.472370, 120.963522);
        waypoints.add(midPoint3);
        GeoPoint midPoint4 = new GeoPoint(14.465598, 120.961511);
        waypoints.add(midPoint4);
        GeoPoint midPoint5 = new GeoPoint(14.449484, 120.954852);
        waypoints.add(midPoint5);
        GeoPoint midPoint6 = new GeoPoint(14.415667, 120.940960);
        waypoints.add(midPoint6);
        GeoPoint midPoint7 = new GeoPoint(14.337469, 120.937251);
        waypoints.add(midPoint7);
        GeoPoint midPoint8 = new GeoPoint(14.256931, 120.972787);
        waypoints.add(midPoint8);
        GeoPoint midPoint10 = new GeoPoint(14.253494, 120.975082);
        waypoints.add(midPoint10);
        GeoPoint midPoint11 = new GeoPoint(14.114538, 120.961288);
        waypoints.add(midPoint11);
        GeoPoint midPoint12 = new GeoPoint(14.101048, 120.927163);
        waypoints.add(midPoint12);
        GeoPoint midPoint13 = new GeoPoint(14.102158, 120.922756);
        waypoints.add(midPoint13);
        GeoPoint destination = new GeoPoint(14.120115, 120.909210);
        waypoints.add(destination);
        fetchTrafficData(waypoints, new TrafficDataCallback() {
            @Override
            public void onTrafficDataFetched(JSONObject trafficData) {
                updateMapWithTrafficData(waypoints, trafficData);
            }
        });
        initialLongitude = 14.510180438746158;
        initialLatitude = 120.99092025344035;
        finalLatitude = 14.120111154056406;
        finalLongitude = 120.90921410865793;
        kalmanFilter.setFinalDestination(finalLatitude, finalLongitude);
        updateRouteOnServer(BusNumber, "PITX-MENDEZ");
    }

    private void getCoordinatesToGenMar() {
        RoadManager roadManager = new OSRMRoadManager(this, "MyOwnUserAgent/1.0");
        // Replace this with the actual coordinates for your predefined locations
        GeoPoint startLocation = new GeoPoint(14.510180438746158, 120.99092025344035);
        mapView.getController().setCenter(startLocation);
        mapView.getController().setZoom(18.0); // Set an appropriate zoom level
        // Update currentLatitude and currentLongitude
        currentLatitude = startLocation.getLatitude();
        currentLongitude = startLocation.getLongitude();
        ArrayList<GeoPoint> waypoints = new ArrayList<GeoPoint>();

        // Updated Waypoints
        GeoPoint start = new GeoPoint(14.508061, 120.988426);
        waypoints.add(start);

        GeoPoint midPoint1 = new GeoPoint(14.502818, 120.989831);
        waypoints.add(midPoint1);

        GeoPoint midPoint2 = new GeoPoint(14.490652, 120.984401);
        waypoints.add(midPoint2);

        GeoPoint midPoint3 = new GeoPoint(14.477716, 120.973102);
        waypoints.add(midPoint3);

        GeoPoint midPoint4 = new GeoPoint(14.472660, 120.961725);
        waypoints.add(midPoint4);

        GeoPoint midPoint5 = new GeoPoint(14.466799, 120.962901);
        waypoints.add(midPoint5);

        GeoPoint midPoint6 = new GeoPoint(14.455615, 120.960443);
        waypoints.add(midPoint6);

        GeoPoint midPoint7 = new GeoPoint(14.420459, 120.966894);
        waypoints.add(midPoint7);

        GeoPoint midPoint8 = new GeoPoint(14.406663, 120.977597);
        waypoints.add(midPoint8);

        GeoPoint midPoint9 = new GeoPoint(14.348681, 120.981071);
        waypoints.add(midPoint9);

        GeoPoint midPoint10 = new GeoPoint(14.327342, 120.985203);
        waypoints.add(midPoint10);

        GeoPoint midPoint11 = new GeoPoint(14.287669, 120.988062);
        waypoints.add(midPoint11);

        GeoPoint midPoint12 = new GeoPoint(14.284225, 120.996550);
        waypoints.add(midPoint12);

        GeoPoint midPoint13 = new GeoPoint(14.285163, 120.996959);
        waypoints.add(midPoint13);

        GeoPoint midPoint14 = new GeoPoint(14.284489, 120.998652);
        waypoints.add(midPoint14);

        // Updated Destination
        GeoPoint destination = new GeoPoint(14.287218, 121.000385);
        waypoints.add(destination);
        fetchTrafficData(waypoints, new TrafficDataCallback() {
            @Override
            public void onTrafficDataFetched(JSONObject trafficData) {
                updateMapWithTrafficData(waypoints, trafficData);
            }
        });
        initialLongitude = 14.510180438746158;
        initialLatitude = 120.99092025344035;
        finalLatitude = 14.287221247673578;
        finalLongitude = 121.00038124642944;
        kalmanFilter.setFinalDestination(finalLatitude, finalLongitude);
        updateRouteOnServer(BusNumber, "PITX-GMA");
    }

    private void getCoordinatesToCavite() {
        RoadManager roadManager = new OSRMRoadManager(this, "MyOwnUserAgent/1.0");
        // Replace this with the actual coordinates for your predefined locations
        GeoPoint startLocation = new GeoPoint(14.510180438746158, 120.99092025344035);
        mapView.getController().setCenter(startLocation);
        mapView.getController().setZoom(18.0); // Set an appropriate zoom level
        // Update currentLatitude and currentLongitude
        currentLatitude = startLocation.getLatitude();
        currentLongitude = startLocation.getLongitude();
        ArrayList<GeoPoint> waypoints = new ArrayList<GeoPoint>();

        // Updated Midpoints
        GeoPoint midPoint1 = new GeoPoint(14.508175, 120.988471);
        waypoints.add(midPoint1);

        GeoPoint midPoint2 = new GeoPoint(14.505922, 120.987609);
        waypoints.add(midPoint2);

        GeoPoint midPoint3 = new GeoPoint(14.504627, 120.990183);
        waypoints.add(midPoint3);

        GeoPoint midPoint4 = new GeoPoint(14.474206, 120.968121);
        waypoints.add(midPoint4);

        GeoPoint midPoint5 = new GeoPoint(14.451877, 120.915961);
        waypoints.add(midPoint5);

        GeoPoint midPoint6 = new GeoPoint(14.446748, 120.911658);
        waypoints.add(midPoint6);

        GeoPoint midPoint7 = new GeoPoint(14.445889, 120.908749);
        waypoints.add(midPoint7);

        GeoPoint midPoint8 = new GeoPoint(14.446677, 120.906571);
        waypoints.add(midPoint8);

        GeoPoint midPoint9 = new GeoPoint(14.445153, 120.906542);
        waypoints.add(midPoint9);

        GeoPoint midPoint10 = new GeoPoint(14.443785, 120.902664);
        waypoints.add(midPoint10);

        GeoPoint midPoint11 = new GeoPoint(14.442433, 120.903609);
        waypoints.add(midPoint11);

        GeoPoint midPoint12 = new GeoPoint(14.433503, 120.887084);
        waypoints.add(midPoint12);

        GeoPoint midPoint13 = new GeoPoint(14.433947, 120.878341);
        waypoints.add(midPoint13);

        GeoPoint midPoint14 = new GeoPoint(14.449711, 120.879566);
        waypoints.add(midPoint14);

        // Updated Destination
        GeoPoint destination = new GeoPoint(14.487290, 120.895122);
        waypoints.add(destination);
        fetchTrafficData(waypoints, new TrafficDataCallback() {
            @Override
            public void onTrafficDataFetched(JSONObject trafficData) {
                updateMapWithTrafficData(waypoints, trafficData);
            }
        });
        initialLongitude = 14.510180438746158;
        initialLatitude = 120.99092025344035;
        finalLatitude = 14.486637109963517;
        finalLongitude = 120.90252274304017;
        kalmanFilter.setFinalDestination(finalLatitude, finalLongitude);
        updateRouteOnServer(BusNumber, "PITX-CAVITE CITY");
    }
//--------------------------------------------------------------------------------------------------------------------
    private void fetchTrafficData(ArrayList<GeoPoint> waypoints, TrafficDataCallback callback) {
        // Build the waypoints string for the request with via for non-stopover waypoints
        StringBuilder waypointsString = new StringBuilder();
        for (int i = 1; i < waypoints.size() - 1; i++) { // Skip the first and last waypoints
            if (waypointsString.length() > 0) {
                waypointsString.append("|");
            }
            waypointsString.append("via:")
                    .append(waypoints.get(i).getLatitude()).append(",").append(waypoints.get(i).getLongitude());
        }

        // Build the URL for the Google Maps Directions API request
        String apiKey = "AIzaSyCV5rAXNR8UWGohQpnrTpz1wf3fbmomDNI";
        String url = "https://maps.googleapis.com/maps/api/directions/json?origin="
                + waypoints.get(0).getLatitude() + "," + waypoints.get(0).getLongitude()
                + "&destination=" + waypoints.get(waypoints.size() - 1).getLatitude() + "," + waypoints.get(waypoints.size() - 1).getLongitude();
        if (waypointsString.length() > 0) {
            url += "&waypoints=" + waypointsString.toString();
        }
        url += "&departure_time=now" // Include departure time parameter
                + "&mode=driving" // Set mode to driving
                + "&key=" + apiKey;

        // Make the request
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Log the entire response
                        Log.d("TrafficDataResponse", response.toString());

                        // Pass the response to the callback
                        callback.onTrafficDataFetched(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Log the error
                        Log.e("TrafficDataError", error.toString());
                        error.printStackTrace();
                    }
                });

        // Add the request to the RequestQueue
        requestQueue.add(jsonObjectRequest);
    }

    public interface TrafficDataCallback {
        void onTrafficDataFetched(JSONObject trafficData);
    }

    private int parseTrafficData(JSONObject trafficData) {
        int trafficDuration = 0;
        try {
            // Log the entire response to debug
            Log.d("TrafficDataResponse", trafficData.toString());

            // Check if "routes" array exists and is not empty
            JSONArray routes = trafficData.getJSONArray("routes");
            if (routes.length() > 0) {
                // Get the first route
                JSONObject route = routes.getJSONObject(0);
                // Check if "legs" array exists and is not empty
                JSONArray legs = route.getJSONArray("legs");
                if (legs.length() > 0) {
                    // Get the first leg
                    JSONObject leg = legs.getJSONObject(0);
                    // Log the leg details
                    Log.d("TrafficDataLeg", leg.toString());

                    // Check if "duration_in_traffic" object exists
                    if (leg.has("duration_in_traffic")) {
                        // Get the duration in traffic
                        JSONObject durationInTraffic = leg.getJSONObject("duration_in_traffic");
                        if (durationInTraffic.has("value")) {
                            trafficDuration = durationInTraffic.getInt("value");
                            Log.d("TrafficData", "Duration in traffic: " + trafficDuration);
                            Toast.makeText(this, "API WORKING", Toast.LENGTH_SHORT).show();
                        } else {
                            Log.e("TrafficData", "Duration in traffic value not found");
                        }
                    } else {
                        Log.e("TrafficData", "Duration in traffic not found");
                    }
                } else {
                    Log.e("TrafficData", "Legs array is empty");
                }
            } else {
                Log.e("TrafficData", "Routes array is empty");
            }
        } catch (JSONException e) {
            Log.e("TrafficData", "JSON parsing error: " + e.getMessage());
            e.printStackTrace();
        }
        return trafficDuration;
    }

    private int parseDurationData(JSONObject trafficData) {
        int travelDuration = 0;
        try {
            // Log the entire response to debug
            Log.d("DurationDataResponse", trafficData.toString());

            // Check if "routes" array exists and is not empty
            JSONArray routes = trafficData.getJSONArray("routes");
            if (routes.length() > 0) {
                // Get the first route
                JSONObject route = routes.getJSONObject(0);
                // Check if "legs" array exists and is not empty
                JSONArray legs = route.getJSONArray("legs");
                if (legs.length() > 0) {
                    // Get the first leg
                    JSONObject leg = legs.getJSONObject(0);
                    // Log the leg details
                    Log.d("DurationDataLeg", leg.toString());

                    // Check if "duration" object exists
                    if (leg.has("duration")) {
                        // Get the duration in traffic
                        JSONObject duration = leg.getJSONObject("duration");
                        if (duration.has("value")) {
                            travelDuration = duration.getInt("value");
                            Log.d("DurationData", "Average Duration: " + travelDuration);
                            Toast.makeText(this, "API WORKING", Toast.LENGTH_SHORT).show();
                        } else {
                            Log.e("DurationData", "Duration in traffic value not found");
                        }
                    } else {
                        Log.e("DurationData", "Duration in traffic not found");
                    }
                } else {
                    Log.e("DurationData", "Legs array is empty");
                }
            } else {
                Log.e("DurationData", "Routes array is empty");
            }
        } catch (JSONException e) {
            Log.e("DurationData", "JSON parsing error: " + e.getMessage());
            e.printStackTrace();
        }
        return travelDuration;
    }

    private void updateMapWithTrafficData(ArrayList<GeoPoint> waypoints, JSONObject trafficData) {
        int trafficDuration = parseTrafficData(trafficData);
        int travelDuration = parseDurationData(trafficData);
        // Clear existing overlays
        for (Overlay overlay : routeOverlays) {
            mapView.getOverlays().remove(overlay);
        }
        routeOverlays.clear();
        // Add the new route with traffic data
        RoadManager roadManager = new OSRMRoadManager(this, "MyOwnUserAgent/1.0");
        Road road = roadManager.getRoad(waypoints);
        Polyline roadOverlay = RoadManager.buildRoadOverlay(road);
        mapView.getOverlays().add(roadOverlay);
        // Optionally, change the color of the roadOverlay based on traffic data
        // Example threshold in seconds (10 minutes)
        if (trafficDuration >= travelDuration + 600) {
            roadOverlay.getOutlinePaint().setColor(Color.RED);
        } else if (trafficDuration >= travelDuration + 300 && trafficDuration < travelDuration + 600) {
            roadOverlay.getOutlinePaint().setColor(Color.parseColor("#FFA500"));
        } else {
            roadOverlay.getOutlinePaint().setColor(Color.GREEN);
        }
        startLocationUpdates();
        mapView.invalidate();
    }
    // Use this method to fetch and update traffic data
    private void updateTrafficData(ArrayList<GeoPoint> waypoints) {
        fetchTrafficData(waypoints, new TrafficDataCallback() {
            @Override
            public void onTrafficDataFetched(JSONObject trafficData) {
                updateMapWithTrafficData(waypoints, trafficData);
            }
        });
    }
}
