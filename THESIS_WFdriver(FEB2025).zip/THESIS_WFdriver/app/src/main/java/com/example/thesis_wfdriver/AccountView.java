package com.example.thesis_wfdriver;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AccountView extends AppCompatActivity {
    String busNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_view);

        // Get the email from the Intent
        busNumber = SharedData.getInstance().getBusNumber();

        // Set the email to the TextView
        TextView emailTextView = findViewById(R.id.emailTextView);
        if (busNumber != null) {
            emailTextView.setText(busNumber);
        } else {
            emailTextView.setText("No bus number provided");
        }


        // Set up the back button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to MainActivity when the back button is pressed
                Intent intent = new Intent(AccountView.this, MainActivity.class);
                intent.putExtra("busNumber", busNumber);
                startActivity(intent);
                finish();
            }
        });
    }
}