package com.example.thesis_wfdriver;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;

public class MapActivity extends AppCompatActivity {
    private MapView mapView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize the map configuration
        Configuration.getInstance().setUserAgentValue(getPackageName());

        // Set up the map view
        mapView = new MapView(this);
        mapView.setTileSource(TileSourceFactory.MAPNIK);

        // Define the bounding box for the Philippines
        BoundingBox philippinesBoundingBox = new BoundingBox(21.5, 126.5, 4.5, 116.5);

        // Set the initial view to the bounding box
        mapView.zoomToBoundingBox(philippinesBoundingBox, true);

        // Restrict the map view to the bounding box
        mapView.setScrollableAreaLimitDouble(philippinesBoundingBox);

        // Set initial zoom and center
        IGeoPoint startPoint = new GeoPoint(12.8797, 121.7740); // Approximate center of the Philippines
        mapView.getController().setZoom(6.0); // Initial zoom level
        mapView.getController().setCenter(startPoint);

        setContentView(mapView);
    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume(); // Needed for compass, my location overlays, v6.0.0 and up
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();  // Needed for compass, my location overlays, v6.0.0 and up
    }
}
