package com.example.thesis_wfdriver;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class KalmanFilter {
    private double AVERAGE_SPEED = 10.0; // km/h

    double[] state = new double[]{0, 0}; // Initial state [latitude, longitude]
    double[][] covariance = new double[][]{{1, 0}, {0, 1}}; // Initial covariance matrix
    double[][] transitionMatrix = new double[][]{{1, 0}, {0, 1}};
    double[][] measurementMatrix = new double[][]{{1, 0}, {0, 1}};
    double[][] measurementCovariance = new double[][]{{1, 0}, {0, 1}};
    double[][] processNoise = new double[][]{{0.1, 0}, {0, 0.1}};
    double nis;

    private double finalLatitude;
    private double finalLongitude;
    public KalmanFilter(double initialLatitude, double initialLongitude) {
        state[0] = initialLatitude; // Set initial latitude
        state[1] = initialLongitude; // Set initial longitude
    }
    public void setFinalDestination(double finalLatitude, double finalLongitude) {
        this.finalLatitude = finalLatitude;
        this.finalLongitude = finalLongitude;
    }

    public void predict() {
        // State prediction (using transition matrix)
        state = matrixMultiply(transitionMatrix, state);

        // Covariance prediction (P = F * P * F^T + Q)
        covariance = matrixAdd(matrixMultiply(matrixMultiply(transitionMatrix, covariance), transpose(transitionMatrix)), processNoise);
    }

    public void update(double[] measurement) {
        // Measurement residual (innovation): y = z - H * x
        double[] innovation = vectorSubtract(measurement, matrixMultiply(measurementMatrix, state));

        // Innovation covariance: S = H * P * H^T + R
        double[][] innovationCovariance = matrixAdd(matrixMultiply(matrixMultiply(measurementMatrix, covariance), transpose(measurementMatrix)), measurementCovariance);

        // Kalman gain: K = P * H^T * S^(-1)
        double[][] kalmanGain = matrixMultiply(matrixMultiply(covariance, transpose(measurementMatrix)), inverse(innovationCovariance));

        // State update: x = x + K * y
        state = vectorAdd(state, matrixMultiply(kalmanGain, innovation));

        // Covariance update: P = (I - K * H) * P
        double[][] identityMatrix = new double[][]{{1, 0}, {0, 1}};
        covariance = matrixMultiply(matrixSubtract(identityMatrix, matrixMultiply(kalmanGain, measurementMatrix)), covariance);

        // Calculate and print NIS
        nis = calculateNIS(innovation, innovationCovariance);
        System.out.printf("NIS: %.6f\n", nis);
    }

    // Calculate Normalized Innovation Squared (NIS)
    public double calculateNIS(double[] innovation, double[][] innovationCovariance) {
        double[] temp = matrixMultiply(inverse(innovationCovariance), innovation);
        double nis = 0.0;
        for (int i = 0; i < innovation.length; i++) {
            nis += innovation[i] * temp[i];
        }
        return nis;
    }


    public static void main(String[] args) throws InterruptedException {
        double initialLatitude = 14.120285484470212; // Set initial latitude
        double initialLongitude = 120.999742; // Set initial longitude

        // Initialize the final latitude and longitude (replace with actual values)
        double finalLatitude = 14.510622;
        double finalLongitude = 120.990726;

        KalmanFilter kf = new KalmanFilter(initialLatitude, initialLongitude);

        // St the average speed in km/h

        // Set a threshold value for distance to final destination
        double thresholdDistance = 0.001; // You can adjust this value as needed

        // Lists for storing ground truth, measurements, and estimates
        List<double[]> groundTruth = new ArrayList<>();
        List<double[]> measurements = new ArrayList<>();
        List<double[]> estimates = new ArrayList<>();

        // Simulate real-time movement until reaching the final latitude and longitude
        while (true) {
            // Get current estimated position
            double estimatedLatitude = kf.state[0];
            double estimatedLongitude = kf.state[1];


            // Store ground truth and estimated positions
            double[] truth = {finalLatitude, finalLongitude};
            double[] estimate = {estimatedLatitude, estimatedLongitude};
            groundTruth.add(truth);
            estimates.add(estimate);

            double mae = calculateMAE(groundTruth, estimates);
            double rmse = calculateRMSE(groundTruth, estimates);
            double mape = calculateMAPE(groundTruth, estimates);


            // Print accuracy metrics
            System.out.printf("Accuracy Metrics:\nMAE: %.6f\nRMSE: %.6f\nMAPE: %.2f%%\n",
                    mae, rmse, mape);
            // Output current estimated position if it's updated
            double distanceToFinal = calculateDistance(estimatedLatitude, estimatedLongitude, finalLatitude, finalLongitude);
            if (distanceToFinal <= thresholdDistance) {
                System.out.println("Final position reached!");
                break; // Exit the loop once the final position is reached
            }

            double timeRemainingMinutes = (distanceToFinal / kf.AVERAGE_SPEED) * 60;
            System.out.printf("Estimated position: Latitude=%.6f, Longitude=%.6f, Time Remaining: %.2f minutes\n", estimatedLatitude, estimatedLongitude, timeRemainingMinutes);

            // Check if the estimated position is reached
            double distanceToEstimated = calculateDistance(estimatedLatitude, estimatedLongitude, finalLatitude, finalLongitude);
            if (distanceToEstimated <= thresholdDistance) {
                // Generate new measurement data (simulate movement)
                double[] measurement = {estimatedLatitude + 0.0001, estimatedLongitude + 0.0001};
                measurements.add(measurement);

                // Update the state based on new measurement
                kf.update(measurement);

                // Predict the next state
                kf.predict();
            }

            // Sleep for a short duration to simulate real-time movement
            TimeUnit.SECONDS.sleep(1);
        }


    }

    public double timeRemainingMinutes(double finalLatitude, double finalLongitude) {
        double distanceToFinal = calculateDistance(state[0], state[1], finalLatitude, finalLongitude);
        return (distanceToFinal / AVERAGE_SPEED) * 60; // Convert hours to minutes
    }

    public double distanceToFinal() {
        return calculateDistance(state[0], state[1], finalLatitude, finalLongitude);
    }

    // Helper methods for matrix and vector operations
    public static double[][] matrixMultiply(double[][] a, double[][] b) {
        int rows = a.length;
        int cols = b[0].length;
        int sumLength = b.length;
        double[][] result = new double[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                for (int k = 0; k < sumLength; k++) {
                    result[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return result;
    }

    public static double[] matrixMultiply(double[][] a, double[] b) {
        int rows = a.length;
        int sumLength = b.length;
        double[] result = new double[rows];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < sumLength; j++) {
                result[i] += a[i][j] * b[j];
            }
        }
        return result;
    }

    public static double[][] transpose(double[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;
        double[][] transposed = new double[cols][rows];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                transposed[j][i] = matrix[i][j];
            }
        }
        return transposed;
    }

    public static double[][] matrixAdd(double[][] a, double[][] b) {
        int rows = a.length;
        int cols = a[0].length;
        double[][] result = new double[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result[i][j] = a[i][j] + b[i][j];
            }
        }
        return result;
    }

    public static double[] vectorAdd(double[] a, double[] b) {
        int length = a.length;
        double[] result = new double[length];

        for (int i = 0; i < length; i++) {
            result[i] = a[i] + b[i];
        }
        return result;
    }

    public static double[] vectorSubtract(double[] a, double[] b) {
        int length = a.length;
        double[] result = new double[length];

        for (int i = 0; i < length; i++) {
            result[i] = a[i] - b[i];
        }
        return result;
    }

    public static double[][] matrixSubtract(double[][] a, double[][] b) {
        int rows = a.length;
        int cols = a[0].length;
        double[][] result = new double[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result[i][j] = a[i][j] - b[i][j];
            }
        }
        return result;
    }

    public static double[][] inverse(double[][] matrix) {
        int n = matrix.length;
        double[][] augmentedMatrix = new double[n][2 * n];
        double[][] inverseMatrix = new double[n][n];

        // Create augmented matrix [matrix | identity]
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                augmentedMatrix[i][j] = matrix[i][j];
                augmentedMatrix[i][j + n] = (i == j) ? 1 : 0;
            }
        }

        // Apply Gaussian elimination
        for (int i = 0; i < n; i++) {
            double pivot = augmentedMatrix[i][i];
            for (int j = 0; j < 2 * n; j++) {
                augmentedMatrix[i][j] /= pivot;
            }

            for (int k = 0; k < n; k++) {
                if (k != i) {
                    double factor = augmentedMatrix[k][i];
                    for (int j = 0; j < 2 * n; j++) {
                        augmentedMatrix[k][j] -= factor * augmentedMatrix[i][j];
                    }
                }
            }
        }

        // Extract the inverse matrix
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                inverseMatrix[i][j] = augmentedMatrix[i][j + n];
            }
        }

        return inverseMatrix;
    }

    // Calculate distance between two points (Haversine formula)
    public static double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371; // Radius of the Earth in km

        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * c;

        return distance;
    }

    private List<double[]> groundTruth = new ArrayList<>();
    private List<double[]> estimates = new ArrayList<>();

    public void addGroundTruth(double[] truth) {
        groundTruth.add(truth);
    }

    public void addEstimate(double[] estimate) {
        estimates.add(estimate);
    }

    public List<double[]> getGroundTruth() {
        return groundTruth;
    }

    public List<double[]> getEstimates() {
        return estimates;
    }

    // Calculate Mean Absolute Error (MAE)
    public static double calculateMAE(List<double[]> groundTruth, List<double[]> estimates) {
        double sum = 0.0;
        for (int i = 0; i < groundTruth.size(); i++) {
            double[] truth = groundTruth.get(i);
            double[] estimate = estimates.get(i);
            sum += Math.abs(truth[0] - estimate[0]) + Math.abs(truth[1] - estimate[1]);
        }
        return sum / groundTruth.size();
    }

    // Calculate Root Mean Squared Error (RMSE)
    public static double calculateRMSE(List<double[]> groundTruth, List<double[]> estimates) {
        double sumSquared = 0.0;
        for (int i = 0; i < groundTruth.size(); i++) {
            double[] truth = groundTruth.get(i);
            double[] estimate = estimates.get(i);
            double errorX = truth[0] - estimate[0];
            double errorY = truth[1] - estimate[1];
            sumSquared += (errorX * errorX) + (errorY * errorY);
        }
        return Math.sqrt(sumSquared / groundTruth.size());
    }

    // Calculate Mean Absolute Percentage Error (MAPE)
    public static double calculateMAPE(List<double[]> groundTruth, List<double[]> estimates) {
        double sumPercentage = 0.0;
        for (int i = 0; i < groundTruth.size(); i++) {
            double[] truth = groundTruth.get(i);
            double[] estimate = estimates.get(i);
            double percentageX = Math.abs((truth[0] - estimate[0]) / truth[0]);
            double percentageY = Math.abs((truth[1] - estimate[1]) / truth[1]);
            sumPercentage += percentageX + percentageY;
        }

        return (sumPercentage / (groundTruth.size() * 2)) * 100;
    }

    public double getAverageSpeed() {
        return this.AVERAGE_SPEED;
    }

    public void setAverageSpeed(double speed) {
        this.AVERAGE_SPEED = speed;
    }


    public double[] getCurrentState() {
        return state;
    }
}